% Alunos:
% - Guilherme Bacca
% - Maicon Santos
% - Mateus Clemer
% - Matheus Klauberg
% - Tamire Kistner

function d = dist(p, q)
  d = sqrt(sum((p .- q) .^ 2));
end


